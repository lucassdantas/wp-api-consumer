<?php
/**
 * Plugin Name: Api Consumer
 * Description: Plugin to send elementor form to API
 * Plugin URI:  https://github.com/lucassdantas/wp-api-consumer.git
 * Version:     1.0.0
 * Author:      R&D Marketing Digital
 * Author URI:  https://rdmarketing.com.br/
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
if(!function_exists('add_action')){
    die;
}
/**
 * Add new subscriber to Sendy.
 *
 * @since 1.0.0
 * @param ElementorPro\Modules\Forms\Registrars\Form_Actions_Registrar $form_actions_registrar
 * @return void
 */
function add_new_sendy_form_action( $form_actions_registrar ) {

	include_once( __DIR__ .  '/form-actions/sendy.php' );

	$form_actions_registrar->register( new Sendy_Action_After_Submit() );

}
add_action( 'elementor_pro/forms/actions/register', 'add_new_sendy_form_action' );